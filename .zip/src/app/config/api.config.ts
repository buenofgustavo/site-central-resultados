export const API_CONFIG = {
  baseUrl: `http://192.168.100.127:8080`
}
