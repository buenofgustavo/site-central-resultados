export interface credenciais {
  email: string;
  senha: string;
}
