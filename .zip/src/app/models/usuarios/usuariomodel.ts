export interface usuario{
  id?: any;
  name: string;
  email: string;
  senha: string;
  perfis: string[];


}
