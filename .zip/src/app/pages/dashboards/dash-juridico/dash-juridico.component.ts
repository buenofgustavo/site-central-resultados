import { Component } from '@angular/core';

@Component({
  selector: 'app-dash-juridico',
  templateUrl: './dash-juridico.component.html',
  styleUrls: ['./dash-juridico.component.scss']
})
export class DashJuridicoComponent {

}
