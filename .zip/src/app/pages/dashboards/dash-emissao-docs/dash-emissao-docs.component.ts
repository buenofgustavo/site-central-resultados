import { Component } from '@angular/core';

@Component({
  selector: 'app-dash-emissao-docs',
  templateUrl: './dash-emissao-docs.component.html',
  styleUrls: ['./dash-emissao-docs.component.scss']
})
export class DashEmissaoDocsComponent {

}
