import { Component } from '@angular/core';

@Component({
  selector: 'app-dash-logistica',
  templateUrl: './dash-logistica.component.html',
  styleUrls: ['./dash-logistica.component.scss']
})
export class DashLogisticaComponent {

}
