import { Component } from '@angular/core';

@Component({
  selector: 'app-dash-ocorrencias',
  templateUrl: './dash-ocorrencias.component.html',
  styleUrls: ['./dash-ocorrencias.component.scss']
})
export class DashOcorrenciasComponent {

}
