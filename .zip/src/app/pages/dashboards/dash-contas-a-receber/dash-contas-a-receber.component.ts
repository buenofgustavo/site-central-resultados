import { Component } from '@angular/core';

@Component({
  selector: 'app-dash-contas-a-receber',
  templateUrl: './dash-contas-a-receber.component.html',
  styleUrls: ['./dash-contas-a-receber.component.scss']
})
export class DashContasAReceberComponent {

}
