import { Component } from '@angular/core';

@Component({
  selector: 'app-dash-performance',
  templateUrl: './dash-performance.component.html',
  styleUrls: ['./dash-performance.component.scss']
})
export class DashPerformanceComponent {

}
