import { Component } from '@angular/core';

@Component({
  selector: 'app-diaria-pj',
  templateUrl: './diaria-pj.component.html',
  styleUrls: ['./diaria-pj.component.scss']
})
export class DiariaPjComponent {

}
